﻿Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()> Public Class $itemname$

    <TestMethod()> Public Sub TestMethod1()
    End Sub

End Class