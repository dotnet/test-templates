﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass>
Public Class $safeitemname$

    <TestMethod>
    Public Sub TestMethod1()

    End Sub

End Class
