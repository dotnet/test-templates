﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("$projectname$")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("$registeredorganization$")>
<Assembly: AssemblyProduct("$projectname$")>
<Assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")>
<Assembly: AssemblyTrademark("")>
<assembly: AssemblyMetadata("TargetPlatform","UAP")>

' <Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
<Assembly: ComVisible(False)>